//
//  ViewController.swift
//  Assignment 3
//
//  Created by Victor Yang on 2020-03-22.
//  Copyright © 2020 COMP2601. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

